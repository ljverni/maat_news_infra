def handler(event, context):
    raise Exception("This Lambda is deployed via CI/CD")
